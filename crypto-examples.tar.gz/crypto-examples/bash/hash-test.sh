#!/bin/bash
#
# Simple openssl command line SHA1 test as per FIPS 180-2.  Using test vectors
# from: http://www.nsrl.nist.gov/testdata/
#
# Alexei Czeskis (2011.02.02)


# Simple wrapper for openssl sha1 function for hashing text.  Return the output
# of the openssl command sanitized to remove the extraneous stdin message.
function sha1_text {
  msg=$1;
  echo -n $msg | openssl dgst -sha1 | sed 's/.* //';
}

# Simple wrapper for openssl sha1 function for hashing file contents.  Return
# the output of the openssl command sanitized to remove the extraneous message.
function sha1_file {
  file_name=$1;
  openssl dgst -sha1 $file_name | sed 's/.* //';
}

echo -n "Testing SHA-1 as per FIPS 180-2: ";
  result=`sha1_text "abc"`;
  expected_result="a9993e364706816aba3e25717850c26c9cd0d89d";
  if [ $result = $expected_result ]; then
    echo -n '1...';
  else
    echo -e "\n ERROR with test input $msg";
  fi

  result=`sha1_text "abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq"`;
  expected_result="84983e441c3bd26ebaae4aa1f95129e5e54670f1";
  if [ $result = $expected_result ]; then
    echo -n '2...';
  else
    echo -e "\n ERROR with test input $msg";
  fi

  result=`sha1_file a_1m.dat`;
  expected_result="34aa973cd4c4daa4f61eeb2bdbad27316534016f";
  if [ $result = $expected_result ]; then
    echo -n '3...';
  else
    echo -e "\n ERROR with test input $msg";
  fi

  echo '[DONE]';
