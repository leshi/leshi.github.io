#!/bin/bash
#
# Simple openssl command line HMAC-SHA-256 test as per IETF RFC 4231.  Using
# test vectors from: http://tools.ietf.org/html/rfc4231#section-4.2
#
# Alexei Czeskis (2011.02.02)


# Simple wrapper for openssl hmac-sha-256 function of some text.  Return the
# output of the openssl command sanitized to remove the extraneous stdin
# message.
function hmac_sha256_text {
  key=$1;
  data=$2;
  echo -n $data | openssl dgst -sha256 -hmac $key | sed 's/.* //';
}

echo -n "Testing HMAC-SHA-256 as per IETF RFC 4231: ";
  result=`hmac_sha256_text "Jefe" "what do ya want for nothing?"`;
  expected_result="5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843";
  if [ $result = $expected_result ]; then
    echo -n '1...';
  else
    echo -e "\n ERROR with test input $msg";
  fi

  key=`echo -e "\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b"`;
  result=`hmac_sha256_text $key "Hi There"`;
  expected_result="b0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7";
  if [ $result = $expected_result ]; then
    echo -n '2...';
  else
    echo -e "\n ERROR with test input $msg";
  fi

  key=`echo -e "\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa"`;
  data=`echo -e "\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd"`;
  result=`hmac_sha256_text $key $data`;
  expected_result="773ea91e36800e46854db8ebd09181a72959098b3ef8c122d9635514ced565fe";
  if [ $result = $expected_result ]; then
    echo -n '3...';
  else
    echo -e "\n ERROR with test input $msg";
  fi

  echo '[DONE]';
