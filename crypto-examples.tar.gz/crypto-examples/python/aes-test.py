#!/usr/bin/python
#
# Demo doing AES in python. Requires PyCrypto
# (http://www.dlitz.net/software/pycrypto/)
#
# Using test vectors from file "CBCVarTxt256e.txt" from:
# http://csrc.nist.gov/groups/STM/cavp/documents/aes/KAT_AES.zip
#
# Alexei Czeskis 2011.02.02

from Crypto.Cipher import AES


def aes256_example():
  """Small aes256 usage example."""

  print "Testing AES-CBC-256 encryption: ",

  # Set up the key and the IV.  We'll be keeping them constant
  key = "\x00"*32
  iv = "\x00"*16
  test_vector = 1

  # Test 1
  cipher = AES.new(key, AES.MODE_CBC, iv)
  m = "\x80" + "\x00" *15
  if cipher.encrypt(m) == "ddc6bf790c15760d8d9aeb6f9a75fd4e".decode('hex'):
    print "%d..." % test_vector,
  else:
    print "Error on test_vector %d" % test_vector;
    exit(test_vector + 1);

  # Test 2
  test_vector += 1
  cipher = AES.new(key, AES.MODE_CBC, iv)
  m = "\xc0" + "\x00" *15
  c = cipher.encrypt(m)
  if c == "0a6bdc6d4c1e6280301fd8e97ddbe601".decode('hex'):
    print "%d..." % test_vector,
  else:
    print "Error on test_vector %d" % test_vector;
    exit(test_vector + 1);

  # Test 3
  test_vector += 1
  cipher = AES.new(key, AES.MODE_CBC, iv)
  m = "\xe0" + "\x00" *15
  if cipher.encrypt(m) == "9b80eefb7ebe2d2b16247aa0efc72f5d".decode('hex'):
    print "%d..." % test_vector,
  else:
    print "Error on test_vector %d" % test_vector;
    exit(test_vector + 1);

  # All done
  print "[DONE]";


if __name__ == '__main__':
  aes256_example()
