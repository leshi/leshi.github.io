#!/usr/bin/python
#
# Demo doing an HMAC in python. Requires PyCrypto
# (http://www.dlitz.net/software/pycrypto/)
#
# Using test vectors from RFC4331: http://tools.ietf.org/html/rfc4231
#
# Alexei Czeskis 2011.02.02

from Crypto.Hash import HMAC
from Crypto.Hash import SHA256


def hmac_sha256_example():
  """Small hmac-sha256 usage example."""
  print "Testing HMAC-SHA256: ",

  # Test Case 1
  test_vector = 1
  hmac = HMAC.new("\x0b"*20, "Hi There", SHA256)
  if hmac.hexdigest() == "b0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7":
    print "%d..." % test_vector,
  else:
    print "Error on test_vector %d" % test_vector;
    exit(test_vector + 1);

  # Test Case 2
  test_vector += 1
  hmac = HMAC.new("Jefe", "what do ya want for nothing?", SHA256)
  if hmac.hexdigest() == "5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843":
    print "%d..." % test_vector,
  else:
    print "Error on test_vector %d" % test_vector;
    exit(test_vector + 1);

  # Test Case 3
  test_vector += 1
  hmac = HMAC.new("\xaa"*20, "\xdd"*50, SHA256)
  if hmac.hexdigest() == "773ea91e36800e46854db8ebd09181a72959098b3ef8c122d9635514ced565fe":
    print "%d..." % test_vector,
  else:
    print "Error on test_vector %d" % test_vector;
    exit(test_vector + 1);

  # All done
  print "[DONE]";


if __name__ == '__main__':
  hmac_sha256_example()
