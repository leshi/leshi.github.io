#!/usr/bin/python
#
# Demo doing MD5 in python. Requires PyCrypto
# (http://www.dlitz.net/software/pycrypto/)
#
# Using test vectors from RFC4331: http://tools.ietf.org/html/rfc4231
#
# Alexei Czeskis 2011.08.23

from Crypto.Hash import MD5


def md5_example():
  """Small md5 usage example."""
  print "Testing md5 example: ",

  # Test Case 1
  test_vector = 1
  md5 = MD5.new("a")
  if md5.hexdigest() == "0cc175b9c0f1b6a831c399e269772661":
    print "%d..." % test_vector,
  else:
    print "Error on test_vector %d" % test_vector;
    exit(test_vector + 1);

  # Test Case 2
  test_vector += 1
  md5 = MD5.new("abc")
  if md5.hexdigest() == "900150983cd24fb0d6963f7d28e17f72":
    print "%d..." % test_vector,
  else:
    print "Error on test_vector %d" % test_vector;
    exit(test_vector + 1);

  # Test Case 3
  test_vector += 1
  md5 = MD5.new("message digest")
  if md5.hexdigest() == "f96b697d7cb7938d525a2f31aaf161d0":
    print "%d..." % test_vector,
  else:
    print "Error on test_vector %d" % test_vector;
    exit(test_vector + 1);

  # All done
  print "[DONE]";


if __name__ == '__main__':
  md5_example()
