#include <stdio.h>
#include <openssl/sha.h>
#include <openssl/rand.h>

/* 
 * Note about OpenSSL/Java JCA interop:
 *  http://forums.sun.com/thread.jspa?threadID=5153188
 *
 * See documentation here:
 *  http://www.openssl.org/docs/crypto/sha.html#
 *
 * Using test vectors from:
 *  http://csrc.nist.gov/groups/ST/toolkit/documents/Examples/SHA512.pdf
 *
 * Tadayoshi Kohno, Alexei Czeskis
 * Last Updated: 2011.02.02
 */


/* Prints an array of len characters long in hex */
void print_hex(unsigned char *str, int len)
{
    int i;
    for (i = 0; i < len; i++)
    {
        printf("%02X " , str[i]);
    }
}

int main(int argc, char * argv[])
{
    SHA512_CTX c;

    // The message
    unsigned char msg[3] = { 
      'a', 'b', 'c',
    } ;
    unsigned int msg_length = 3;

    // buffer for message digest
    unsigned char md[64] = {
      0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0,
    };
    unsigned int md_length = 64;

    printf("before\n");
    printf("msg:\t"); print_hex(msg, msg_length); printf("\n");
    printf("md:\t"); print_hex(md, md_length); printf("\n");

    SHA512_Init(&c);
    SHA512_Update(&c, msg, msg_length);
    SHA512_Final(md, &c);


    printf("\nafter\n");
    printf("msg:\t"); print_hex(msg, msg_length); printf("\n");
    printf("md:\t"); print_hex(md, md_length); printf("\n");


    unsigned char correct[64] = {
      0xdd, 0xaf, 0x35, 0xa1, 0x93, 0x61, 0x7a, 0xba,
      0xcc, 0x41, 0x73, 0x49, 0xae, 0x20, 0x41, 0x31,
      0x12, 0xe6, 0xfa, 0x4e, 0x89, 0xa9, 0x7e, 0xa2,
      0x0a, 0x9e, 0xee, 0xe6, 0x4b, 0x55, 0xd3, 0x9a,
      0x21, 0x92, 0x99, 0x2a, 0x27, 0x4f, 0xc1, 0xa8,
      0x36, 0xba, 0x3c, 0x23, 0xa3, 0xfe, 0xeb, 0xbd,
      0x45, 0x4d, 0x44, 0x23, 0x64, 0x3c, 0xe8, 0x0e,
      0x2a, 0x9a, 0xc9, 0x4f, 0xa5, 0x4c, 0xa4, 0x9f,
    };

    int i;
    for( i = 0; i < 64; i++ ) {
      if( correct[i] != md[i] ) {
        printf("ERROR, digest[%d] isn't correct\n", i);
        printf("correct\t"); print_hex(correct, md_length);
        exit(1);
      }
    }
    printf("\nDigest is correct\n");

    return(0);
}

