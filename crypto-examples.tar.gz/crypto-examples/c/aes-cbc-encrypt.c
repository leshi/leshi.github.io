#include <stdio.h>
#include <openssl/aes.h>
#include <openssl/rand.h>

/* 
 * Note about OpenSSL/Java JCA interop:
 *  http://forums.sun.com/thread.jspa?threadID=5153188
 */


void print_hex(unsigned char *str, int len)
{
    int i;
    for (i = 0; i < len; i++)
    {
	printf("%02X " , str[i]);
    }
}

int main(int argc, char * argv[])
{
    AES_KEY enckey;
    AES_KEY deckey;
    int i;

    unsigned char keystr[32] = {    
	    0x80, 0, 0, 0, 0, 0, 0, 0,
	    0, 0, 0, 0, 0, 0, 0, 0,
	    0, 0, 0, 0, 0, 0, 0, 0,
	    0, 0, 0, 0, 0, 0, 0, 1 };

    unsigned char IV[16] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 } ;

    unsigned char IVfresh[16] = {   /* should be same as above IV */
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 } ;


    unsigned char ptxt1[32] = { 
      0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
      0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
      0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17,
      0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f, } ;

    unsigned char ptxt2[32] = { 
	    0, 0, 0, 0, 0, 0, 0, 0,
	    0, 0, 0, 0, 0, 0, 0, 0, 
	    0, 0, 0, 0, 0, 0, 0, 0,
	    0, 0, 0, 0, 0, 0, 0, 0, 
	} ;


    unsigned char ctxt1[32] = { 
	    0, 0, 0, 0, 0, 0, 0, 0,
	    0, 0, 0, 0, 0, 0, 0, 0,
	    0, 0, 0, 0, 0, 0, 0, 0,
	    0, 0, 0, 0, 0, 0, 0, 0,
	} ;



    printf("before\n");
    printf("key:\t"); print_hex(keystr, 32); printf("\n");
    printf("ptxt1:\t"); print_hex(ptxt1, 32); printf("\n");
    printf("IV:\t"); print_hex(IV, 16); printf("\n");
    printf("IVfresh:\t"); print_hex(IVfresh, 16); printf("\n");
    printf("ctxt1:\t"); print_hex(ctxt1, 32); printf("\n");
    printf("ptxt2:\t"); print_hex(ptxt2, 32); printf("\n");

    /* encrypt */
    AES_set_encrypt_key(keystr, 256, &enckey);
    AES_cbc_encrypt(ptxt1, ctxt1, 32, &enckey, IV, AES_ENCRYPT);

/*
    AES_set_encrypt_key(keystr, 256, &enckey);
    AES_set_decrypt_key(keystr, 256, &deckey);
    AES_encrypt(ptxt1, ctxt, &enckey);
    AES_decrypt(ctxt, ptxt2, &deckey);
*/

    printf("\nafter encrypt (IV here may be garbled)\n");
    printf("key:\t"); print_hex(keystr, 32); printf("\n");
    printf("ptxt1:\t"); print_hex(ptxt1, 32); printf("\n");
    printf("IV:\t"); print_hex(IV, 16); printf("\n");
    printf("IVfresh:\t"); print_hex(IVfresh, 16); printf("\n");
    printf("ctxt1:\t"); print_hex(ctxt1, 32); printf("\n");
    printf("ptxt2:\t"); print_hex(ptxt2, 32); printf("\n");

    /* decrypt */
    AES_set_decrypt_key(keystr, 256, &deckey);
    AES_cbc_encrypt(ctxt1, ptxt2, 32, &deckey, IVfresh, AES_DECRYPT);

    printf("\nafter decrypt (IVs here may be garbled)\n");
    printf("key:\t"); print_hex(keystr, 32); printf("\n");
    printf("ptxt1:\t"); print_hex(ptxt1, 32); printf("\n");
    printf("IV:\t"); print_hex(IV, 16); printf("\n");
    printf("IVfresh:\t"); print_hex(IVfresh, 16); printf("\n");
    printf("ctxt1:\t"); print_hex(ctxt1, 32); printf("\n");
    printf("ptxt2:\t"); print_hex(ptxt2, 32); printf("\n");


    return(0);
}


/* Real AES test vectors:
 *
 * Test vectors are a set of known ciphers for a given input and key. For example, for the 128-bit key "00010203050607080A0B0C0D0F101112" (16 bytes represented as two hexadecimal characters per byte), and an input "506812A45F08C889B97F5980038B8359" the AES-128 cipher output should be "D8F532538289EF7D06B506A4FD5BE9C9". Following are some more test vectors:
 *
 * Assume that all tests use this input "4EC137A426DABF8AA0BEB8BC0C2B89D6"
 *
 * AES-128 key "95A8EE8E89979B9EFDCBC6EB9797528D"
 * Ciphered output "D9B65D1232BA0199CDBD487B2A1FD646", deciphered output "9570C34363565B393503A001C0E23B65"
 *
 * AES-192 key "95A8EE8E89979B9EFDCBC6EB9797528D432DC26061553818"
 * Ciphered output "B18BB3E7E10732BE1358443A504DBB49", deciphered output "29DFD75B85CEE4DE6E26A808CDC2C9C3"
 *
 * AES-256 key "95A8EE8E89979B9EFDCBC6EB9797528D432DC26061553818EA635EC5D5A7727E"
 * Ciphered output "2F9CFDDBFFCDE6B9F37EF8E40D512CF4", deciphered output "110A3545CE49B84BBB7B35236108FA6E"
 */
