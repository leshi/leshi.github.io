#include <stdio.h>
#include <openssl/aes.h>
#include <openssl/rand.h>

/* 
 * Note about OpenSSL/Java JCA interop:
 *  http://forums.sun.com/thread.jspa?threadID=5153188
 *
 * Tadayoshi Kohno, Alexei Czeskis
 * Last revision: 2011.02.02
 */


void print_hex(unsigned char *str, int len)
{
    int i;
    for (i = 0; i < len; i++)
    {
      printf("%02x", str[i]);
    }
}

int main(int argc, char * argv[])
{
    AES_KEY enckey;

    unsigned char keystr[32] = {    
	    0x80, 0, 0, 0, 0, 0, 0, 0,
	    0, 0, 0, 0, 0, 0, 0, 0,
	    0, 0, 0, 0, 0, 0, 0, 0,
	    0, 0, 0, 0, 0, 0, 0, 0 };
    unsigned char ptxt[16] = {
      0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0 };
    unsigned char ctxt[16] = {
      0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0 };

    unsigned char ctxt_correct[16]  = {
      0xE3, 0x5A, 0x6D, 0xCB, 0x19, 0xB2, 0x01, 0xA0, 
      0x1E, 0xBC, 0xFA, 0x8A, 0xA2, 0x2B, 0x57, 0x59 };

    printf("before\n");
    printf("key:\t"); print_hex(keystr, 32); printf("\n");
    printf("ptxt:\t"); print_hex(ptxt, 16); printf("\n");
    printf("ctxt:\t"); print_hex(ctxt, 16); printf("\n");

    AES_set_encrypt_key(keystr, 256, &enckey);
    AES_encrypt(ptxt, ctxt, &enckey);

    printf("\nafter\n");
    printf("key:\t"); print_hex(keystr, 32); printf("\n");
    printf("ptxt:\t"); print_hex(ptxt, 16); printf("\n");
    printf("ctxt:\t"); print_hex(ctxt, 16); printf("\n");

    int i = 0;
    for(; i < 16; i++) {
      if( ctxt_correct[i] != ctxt[i]) {
        printf("Error: mismatch in ciphertexts at position %d\n", i);
        printf("Expected: %02X, Got %02X\n", ctxt_correct[i], ctxt[i]);
        exit(0);
      }
    }
    printf("\nCiphertext is correct!\n");

    return(0);
}
