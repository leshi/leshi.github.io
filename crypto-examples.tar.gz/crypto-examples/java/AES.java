/**
 * Simple example of how to encrypt using AES.
 * 
 * Miro Enev, Alexei Czeskis
 * Last edit: 2011.02.02
 */
import java.util.*;
import javax.crypto.*;
import javax.crypto.spec.*;

public class AES {
	// returns hex String representation of a byte array
	static public String bytesToHex(byte [] b) {
		String result = "";
		for (int i = 0; i < b.length; i++) 
			result += byteToHex ( b[i] );
		return result;
	}
	
    static public String byteToHex(byte b) {    	
    	char hexDigit[] = { '0', '1', '2', '3', '4', '5', '6', '7', 
    						'8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
    	char[] array = { hexDigit[(b >> 4) & 0x0f], hexDigit[b & 0x0f] };
		return new String(array);
    }
	
	public static void main(String[] args) throws Exception {

		// Generate the secret key specs.
		byte[] raw = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
								  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		byte[] iv = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		byte[] message = new byte [] { (byte) 0x80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		
		// Feedback
		System.out.println("Key (hex):\t" + bytesToHex(raw));
		System.out.println("IV (hex):\t" + bytesToHex(iv));
		System.out.println("Message (hex):\t" + bytesToHex(message));
		
		// Get the KeyGenerator and generate key object
		KeyGenerator kgen = KeyGenerator.getInstance("AES");
		kgen.init(256);
		SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
		IvParameterSpec ips = new IvParameterSpec(iv);

		// Instantiate the cipher and encrypt
		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		cipher.init(Cipher.ENCRYPT_MODE, skeySpec, ips);
		byte[] ciphertext = cipher.doFinal(message);
		
		// Feedback
		String pretty_ciphertext = bytesToHex(ciphertext);
		System.out.println("Ciphertext (hex): " + pretty_ciphertext);
		
		if(!pretty_ciphertext.equals("ddc6bf790c15760d8d9aeb6f9a75fd4e33e9f5efd85d25133e7e95cfb832ddd9")) {
			System.out.println("Error, unexpected ciphertext");
		}
		else {
			System.out.println("Yay!  Ciphertext is as expected!");
		}
	}
}