/**
 * Simple example of how to do an HMAC in java
 *
 * Miro Enev, Alexei Czeskis
 * last edit: 2011.02.02
 */
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;

public class HMAC_Example {
	
	// returns hex String representation of a byte array
	static public String bytesToHex(byte [] b) {
		String result = "";
		for (int i = 0; i < b.length; i++) 
			result += byteToHex ( b[i] );
		return result;
	}
	
	// returns hex String representation of a byte
    static public String byteToHex(byte b) {    
    	char hexDigit[] = { '0', '1', '2', '3', '4', '5', '6', '7', 
    						'8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
    	char[] array = { hexDigit[(b >> 4) & 0x0f], hexDigit[b & 0x0f] };
		return new String(array);
    }	
    	
    public static void main(String args[])
    {
    	// Set up key and msg
    	byte[] key = new byte[] {
    			(byte) 0x0b, (byte) 0x0b, (byte) 0x0b, (byte) 0x0b,
    			(byte) 0x0b, (byte) 0x0b, (byte) 0x0b, (byte) 0x0b,
    			(byte) 0x0b, (byte) 0x0b, (byte) 0x0b, (byte) 0x0b,
    			(byte) 0x0b, (byte) 0x0b, (byte) 0x0b, (byte) 0x0b,
    			(byte) 0x0b, (byte) 0x0b, (byte) 0x0b, (byte) 0x0b };
    	
    	byte[] msg =  new byte [] {
    			(byte) 0x48, (byte) 0x69, (byte) 0x20, (byte) 0x54,
    			(byte) 0x68, (byte) 0x65, (byte) 0x72, (byte) 0x65 };
    	
    	System.out.println("Key (hex): " + bytesToHex(key));
    	System.out.println("Msg (hex): " + bytesToHex(msg));
    	
    	try {
    		
    		// Init key
    		SecretKeySpec secretKeySpec = new SecretKeySpec(key, "HmacSHA256");
    		
    		// Init HMAC
    		Mac mac = Mac.getInstance("HmacSHA256");
    		mac.init(secretKeySpec);
    		
    		// Perform HMAC and make it pretty
    		byte[] result = mac.doFinal(msg);
        	String pretty_result = bytesToHex(result);
            
        	// Feedback
            System.out.println("Mac (hex): " + pretty_result );
            if(pretty_result.equals("b0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7")) {
            	System.out.println("Yay, HMAC is correct!");
            }
            else {
            	System.out.println("Boo, looks like HMAC is wrong!");
            }
    		
    	} catch (Exception e) {
    		System.out.println("error");
    	}    	        	
    }
}
